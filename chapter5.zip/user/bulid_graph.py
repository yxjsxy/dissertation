import os
import json
import sys
import csv
from sentence_transformers import SentenceTransformer, util
csv.field_size_limit(sys.maxsize)
import random
import datetime
import requests
from tweet_graph import *
import pickle as pkl
from transformers import LongformerModel, LongformerConfig
from transformers import RobertaTokenizer
import torch
import torch.nn.functional as F

data_dir="data"
tweet_collection="dehydrate_tweet_collection.json"
user_profile="dehydrate_user_profile.json"
english_news="english_news.csv"
news_collection="news_collection.json"
news_tweet_relation="news_tweet_relation.json"
tweet_tweet_relation="tweet_tweet_relation.json"# coding: utf8

# 下载图片
def download_img(img_url,new_id):
    r = requests.get(img_url,stream=True)
    print(r.status_code) # 返回状态码
    if r.status_code == 200:
        open('/home/mist/fake_test/data/news_img/'+str(new_id)+".jpg", 'wb').write(r.content) # 将内容写入图片
    del r
    
def load_data():
    
    #加载推文的数据:推文->用户     
    tweet_map={}
    with open(os.path.join(data_dir,tweet_collection)) as f:
        for line in f:
            line=line.strip()
            line=json.loads(line)
            if line["tweet_id"] is None or line["user_id"] is None:
                continue
                
            #生成随机的时间戳            
            timestamp = random.uniform(datetime.datetime.now().timestamp()-50000000, datetime.datetime.now().timestamp())
            date_time = datetime.datetime.fromtimestamp(timestamp)
            tweet_map[line["tweet_id"]]={"user_id":line["user_id"],"time":date_time}
    print("收集推文数",len(tweet_map))
                
    #加载用户的信息数据   
    # ['user_id', 'recent_tweet_ids']
    user_profile_data={}
    with open(os.path.join(data_dir,user_profile)) as f:
        for line in f:
            line=line.strip()
            line=json.loads(line)
            user_profile_data[line["user_id"]]=line["recent_tweet_ids"]
    print("收集用户数",len(user_profile_data))
    
    #加载新闻数据信息
    #表头为：news_id,agency,claim,fact_url,label,lang,ref_source,ref_source_url,statement     
    en_news_data={}
    with open(os.path.join(data_dir,english_news), newline='') as csvfile:
        spamreader = csv.reader(csvfile, delimiter=',')
        header=next(spamreader)
        for row in spamreader:
            try:
                news_id=row[header.index("news_id")]
                label=row[header.index("label")]
                #推文             
                claim=row[header.index("claim")]
                ref_source=json.loads(row[header.index("ref_source")])
                title=ref_source["title"]
                text=ref_source["text"]
                top_img=ref_source["top_img"]
                en_news_data[news_id]={"claim":claim,"ref_source":ref_source,"title":title,"text":text,"top_img":top_img}
            except Exception as e:
                continue 
    print("收集新闻数",len(en_news_data))
    
    
    #加载推文与新闻的关系   
    tweet_news_data={}
    with open(os.path.join(data_dir,news_tweet_relation)) as f:
        for line in f:
            line=line.strip()
            line=json.loads(line)
            news_id=line["news_id"]
            tweet_list=line["tweet_list"]
            for item in tweet_list:
                try:
                    tweet_id=item["$numberLong"]
                    tweet_news_data[tweet_id]=news_id
                except Exception as e:
                    continue 
    print("收集推特与新闻的关系",len(tweet_news_data))
    
    #需要下载news里的图片,运行过后就不需要再运行了
    """
    for news_id,news_content in en_news_data.items():
        top_img=news_content["top_img"]
        #下载链接里的图片         
        try:
            download_img(top_img,news_id)
        except Exception as e:
            continue 
    """
    return tweet_map,user_profile_data,en_news_data,tweet_news_data
    

#构建图     
def build_graph():
    # tweet_map,user_profile_data,en_news_data,tweet_news_data=load_data()
    # pkl.dump(tweet_map,open("save/tweet_map.pkl","wb"))
    # pkl.dump(user_profile_data,open("save/user_profile_data.pkl","wb"))
    # pkl.dump(en_news_data,open("save/en_news_data.pkl","wb"))
    # pkl.dump(tweet_news_data,open("save/tweet_news_data.pkl","wb"))
    tweet_map=pkl.load(open("save/tweet_map.pkl","rb"))
    user_profile_data=pkl.load(open("save/user_profile_data.pkl","rb"))
    en_news_data=pkl.load(open("save/en_news_data.pkl","rb"))
    tweet_news_data=pkl.load(open("save/tweet_news_data.pkl","rb"))
    tg=tweet_graph()
    tg.build_graph(tweet_map,user_profile_data,en_news_data,tweet_news_data)
   
    
if __name__ == '__main__':
    build_graph()
    # similarity_news_text()