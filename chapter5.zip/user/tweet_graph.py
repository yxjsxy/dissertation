from tqdm import tqdm
import pickle as pkl
from collections import Counter
import math
from utils import *

class edge(object):
    """边"""
    def __init__(self):
        super(edge, self).__init__()
        self.in_node=None
        self.out_node=None
        self.type=None
        self.weight=None
        
class tweet_graph(object):
    """推特推文图."""
    def __init__(self):
        super(tweet_graph, self).__init__()
        #定义节点         
        self.tweet_nodes=[]
        self.edges=[]
        self.news=[]
    def build_graph(self,tweet_map,user_profile_data,en_news_data,tweet_news_data):
        self.tweet_map=tweet_map
        self.tweet_news_data=tweet_news_data
        self.en_news_data=en_news_data
        
        #初始化节点
        with open("save/tweet_nodes.csv","w") as f:
            for tweet_id,node_content in tweet_map.items():
                #保留引用新闻的推特
                if tweet_id in tweet_news_data:
                    news_id_i=tweet_news_data[tweet_id]
                    if news_id_i not in en_news_data or  not os.path.isfile(os.path.join("data","news_img",news_id_i+".jpg")):
                        continue
                    self.news.append(tweet_news_data[tweet_id])
                    self.tweet_nodes.append(tweet_id)
                    
                    
        #选择一部分节点,1000个
        self.tweet_nodes=self.tweet_nodes[:1000]
        print("影响图有节点个数:",len(self.tweet_nodes))
        
        #开始构造边
        edges_count=0
        with open("save/edges.csv","w") as f:
            for node_i in tqdm(range(len(self.tweet_nodes))):
                for node_j in range(node_i+1,len(self.tweet_nodes)):
                    #计算两个节点的时间   
                    node_i_t=tweet_map[self.tweet_nodes[node_i]]["time"]
                    node_j_t=tweet_map[self.tweet_nodes[node_j]]["time"]
                    node_i_u=tweet_map[self.tweet_nodes[node_i]]["user_id"]
                    node_j_u=tweet_map[self.tweet_nodes[node_j]]["user_id"]
                    node_i_a=self.news[node_i]
                    node_j_a=self.news[node_j]
                    if node_i_t<node_j_t:
                        e=edge()
                        e.in_node=self.tweet_nodes[node_i]
                        e.out_node=self.tweet_nodes[node_j]
                        if node_i_u != node_j_u:
                            e.type="External"
                        elif node_i_a!=node_j_a :
                            e.type="Internal"
                        else:
                            continue
                        self.edges.append(e)
                        f.write(str(node_i)+","+str(node_j)+","+e.type)
                        edges_count+=1
        pkl.dump(self.edges,open("save/edges.pkl","wb"))
        
        self.edges=pkl.load(open("save/edges.pkl","rb"))
        print("影响图有边个数:",len(self.edges))
        
        self.set_weight()
        
    #计算时间差   
    def get_detal_t(self,e_in,e_out):
        node_i_t=self.tweet_map[e_in]["time"]
        node_j_t=self.tweet_map[e_out]["time"]
        detal_t=(node_j_t-node_i_t).total_seconds()//3600
        value_detal_t=math.exp(1-detal_t)
        return value_detal_t
    
    #计算相似度推文之间的
    def get_similarity_cij(self,e_in,e_out):
        node_i_c=self.en_news_data[self.tweet_news_data[e_in]]["claim"]
        node_j_c=self.en_news_data[self.tweet_news_data[e_out]]["claim"]
        sim_cij=similarity_posts(node_i_c,node_j_c)
        return sim_cij
    
    #计算新闻之间的相似度文本+图像特征
    def get_similarity_aij(self,e_in,e_out):
        news_id_i=self.tweet_news_data[e_in]
        news_id_j=self.tweet_news_data[e_out]
        
        #计算文本
        node_i_a_text=self.en_news_data[news_id_i]["text"]
        node_j_a_text=self.en_news_data[news_id_j]["text"]
        sim_aij_text=similarity_news_text(node_i_a_text,node_j_a_text)
        
        #计算图像         
        img_i_file=os.path.join("data","news_img",news_id_i+".jpg")
        img_j_file=os.path.join("data","news_img",news_id_j+".jpg")
        
        sim_vij_vis=0
        if os.path.isfile(img_i_file) and os.path.isfile(img_j_file):
            sim_vij_vis=similarity_news_visual(img_i_file,img_j_file)
        
        mu=0.8
        sim_score=mu*sim_aij_text+(1-mu)*sim_vij_vis
        return sim_score
            
    #计算权重     
    def set_weight(self):
        # 计算权重
        for e in tqdm(self.edges):
            e_in=e.in_node
            e_out=e.out_node
            
            #时间差             
            value_detal_t=self.get_detal_t(e_in,e_out)
            
            #推文的相似度             
            sim_cij=self.get_similarity_cij(e_in,e_out)
            
            #新闻的相似度             
            sim_aij=self.get_similarity_aij(e_in,e_out)
            
            e.weight=value_detal_t*sim_cij*sim_aij
        
        pkl.dump(self.edges,open("save/edges.pkl","wb"))
        
        
if __name__ == '__main__':
    tg=tweet_graph()