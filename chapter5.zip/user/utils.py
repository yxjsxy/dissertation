import os
import json
import sys
import csv
import random
import datetime
import pickle as pkl
import torch
import torch.nn.functional as F

def pad_to_window_size(input_ids: torch.Tensor, attention_mask: torch.Tensor,
                       one_sided_window_size: int, pad_token_id: int):
    w = int(2 * one_sided_window_size)
    seqlen = input_ids.size(1)
    padding_len = (w - seqlen % w) % w
    input_ids = F.pad(input_ids, (0, padding_len), value=pad_token_id)
    attention_mask = F.pad(attention_mask, (0, padding_len), value=False)  # no attention on the padding tokens
    return input_ids, attention_mask

# LongformerModel 计算新闻文章的相似度文本
def similarity_news_text(s1="",s2="",model=None):
    model = LongformerModel.from_pretrained("models/longformer/longformer-base-4096")
    tokenizer = RobertaTokenizer.from_pretrained('models/roberta-base')
    tokenizer.model_max_length = model.config.max_position_embeddings
    
    input_ids = torch.tensor(tokenizer.encode([s1])).unsqueeze(0)  # batch of size 1
    attention_mask = torch.ones(input_ids.shape, dtype=torch.long, device=input_ids.device) # initialize to local attention
    input_ids, attention_mask = pad_to_window_size(
            input_ids, attention_mask, model.config.attention_window[0], tokenizer.pad_token_id)
    output1 = model(input_ids, attention_mask=attention_mask)[0]
    
    input_ids = torch.tensor(tokenizer.encode([s2])).unsqueeze(0)  # batch of size 1
    attention_mask = torch.ones(input_ids.shape, dtype=torch.long, device=input_ids.device) # initialize to local attention
    input_ids, attention_mask = pad_to_window_size(
            input_ids, attention_mask, model.config.attention_window[0], tokenizer.pad_token_id)
    output2 = model(input_ids, attention_mask=attention_mask)[0]
    cos_sim = util.cos_sim(output1.view(-1), output2.view(-1))
    return cos_sim

# SentenceTransformer 计算推文的相似度
def similarity_posts(s1,s2,model=None):
    model = SentenceTransformer('models/all-roberta-large-v1')
    emb1 = model.encode(s1)
    emb2 = model.encode(s2)
    cos_sim = util.cos_sim(emb1, emb2)
    return cos_sim

# 计算新闻文章的相似度图像
def similarity_news_visual(img_i,img_j,model=None):
    model = deep_rank_model()
    model.load_weights("models/Deep-Ranking/deepranking-v2-150000.h5")
    image1 = load_img(img_i)
    image1 = img_to_array(image1).astype("float64")
    image1 = transform.resize(image1, (224, 224))
    image1 *= 1. / 255
    image1 = np.expand_dims(image1, axis = 0)
    embedding1 = model.predict([image1, image1, image1])[0]
    image2 =load_img(img_j)
    image2 = img_to_array(image2).astype("float64")
    image2 = transform.resize(image2, (224, 224))
    image2 *= 1. / 255
    image2 = np.expand_dims(image2, axis = 0)
    embedding2 = model.predict([image2,image2,image2])[0]
    cos_sim = util.cos_sim(embedding1, embedding2)
    return cos_sim